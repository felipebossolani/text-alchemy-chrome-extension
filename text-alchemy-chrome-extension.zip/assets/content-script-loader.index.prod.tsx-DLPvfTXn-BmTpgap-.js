(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.prod.tsx-DLPvfTXn.js")
    );
  })().catch(console.error);

})();
